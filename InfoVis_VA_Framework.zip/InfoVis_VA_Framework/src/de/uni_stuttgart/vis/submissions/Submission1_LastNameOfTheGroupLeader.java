package de.uni_stuttgart.vis.submissions;

import java.util.List;

import de.uni_stuttgart.vis.framework.InfoVisFramework;
import de.uni_stuttgart.vis.geom.AbstractGeometry;

public class Submission1_LastNameOfTheGroupLeader extends InfoVisFramework {

	@Override
	public List<AbstractGeometry> mapData() {
		// TODO Auto-generated method stub
		return null;
	}

}
